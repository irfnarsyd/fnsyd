
public class Balok extends BangunRuang {
	private int panjang,lebar,tinggi;

	@Override
	double luas() {
		double luas = (2* panjang * lebar)+(2 * panjang * tinggi)+(2 * lebar * tinggi);
		System.out.println("Luas balok adalah : "+ luas);
		return super.luas();
	}

	@Override
	double keliling() {
		double keliling = 4 * (panjang + lebar + tinggi);
		System.out.println("Keliling balok adalah : "+ keliling);
		return super.keliling();
	}

	@Override
	double volume() {
		double volume = panjang*lebar*tinggi;
		System.out.println("Volume balok adalah : " + volume);
		return super.volume();
	}

	public int getPanjang() {
		return panjang;
	}

	public void setPanjang(int panjang) {
		this.panjang = panjang;
	}

	public int getLebar() {
		return lebar;
	}

	public void setLebar(int lebar) {
		this.lebar = lebar;
	}

	public int getTinggi() {
		return tinggi;
	}

	public void setTinggi(int tinggi) {
		this.tinggi = tinggi;
	}

	public Balok(int panjang, int lebar, int tinggi) {
		super();
		this.panjang = panjang;
		this.lebar = lebar;
		this.tinggi = tinggi;
	}
	
}
