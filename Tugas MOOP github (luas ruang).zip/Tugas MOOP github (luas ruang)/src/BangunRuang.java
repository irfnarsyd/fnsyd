
public class BangunRuang {
	double luas() {
		return 0;
	}
	
	double keliling() {
		return 0;
	}
	
	double volume() {
		return 0;
	}
}
