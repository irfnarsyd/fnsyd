
public class Lingkaran extends BangunDatar{
	private int r;

	@Override
	double luas() {
		double luas = (float) (Math.PI * r * r);
        System.out.println("Luas lingkaran adalah : " + luas);
		return super.luas();
	}

	@Override
	double keliling() {
		double keliling = (float) (2 * Math.PI * r);
        System.out.println("Keliling lingkaran adalah : " + keliling);
		return super.keliling();
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public Lingkaran(int r) {
		super();
		this.r = r;
	}
	
	
}
