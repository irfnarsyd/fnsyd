import java.util.Scanner;

public class Testing {
	Scanner scan = new Scanner(System.in);

	void Ruang() {
		int pilih;

		System.out.println("silahkan memilih bangun ruang persegi:");
		System.out.println("===========================");
		System.out.println("1. Kubus");
		System.out.println("2. Balok");
		System.out.println("3. Bola");
		System.out.println("Pilihan : ");
		pilih = scan.nextInt();
		scan.nextLine();

		switch (pilih) {
		case 1:
			int sisi;
			System.out.println("Masukan sisi : ");
			sisi = scan.nextInt();
			scan.nextLine();
			Kubus kubus = new Kubus(sisi);

			kubus.luas();
			kubus.keliling();
			kubus.volume();
			break;
		case 2:
			int panjang, lebar, tinggi;
			System.out.println("Masukan panjang : ");
			panjang = scan.nextInt();
			scan.nextLine();
			System.out.println("Masukan lebar : ");
			lebar = scan.nextInt();
			scan.nextLine();
			System.out.println("Masukan tinggi : ");
			tinggi = scan.nextInt();
			scan.nextLine();
			Balok balok = new Balok(panjang, lebar, tinggi);

			balok.luas();
			balok.keliling();
			balok.volume();
			break;
		case 3:
			int r;
			System.out.println("Masukan jari-jari : ");
			r = scan.nextInt();
			scan.nextLine();
			Bola bola = new Bola(r);

			bola.luas();
			bola.keliling();
			bola.volume();
			break;
		}

	}

	void Datar() {
		int pilih;

		System.out.println("Silahkan Pilih Bangun Datar");
		System.out.println("===========================");
		System.out.println("1. Persegi");
		System.out.println("2. Persegi Panjang");
		System.out.println("3. Lingkaran");
		System.out.println("4. Segitiga");
		System.out.println("Pilihan : ");
		pilih = scan.nextInt();
		scan.nextLine();

		switch (pilih) {
		case 1:
			int sisi;
			System.out.println("Masukan sisi : ");
			sisi = scan.nextInt();
			scan.nextLine();
			Persegi persegi = new Persegi(sisi);

			persegi.luas();
			persegi.keliling();
			break;
		case 2:
			int panjang, lebar;
			System.out.println("Masukan panjang : ");
			panjang = scan.nextInt();
			scan.nextLine();
			System.out.println("Masukan lebar : ");
			lebar = scan.nextInt();
			scan.nextLine();
			PersegiPanjang persegiPanjang = new PersegiPanjang(lebar, panjang);

			persegiPanjang.luas();
			persegiPanjang.keliling();
			break;
		case 3:
			int r;
			System.out.println("Masukan jari-jari : ");
			r = scan.nextInt();
			scan.nextLine();
			Lingkaran lingkaran = new Lingkaran(r);

			lingkaran.luas();
			lingkaran.keliling();
			break;
		case 4:
			int alas, tinggi, sisi1, sisi2, sisi3;
			System.out.println("Masukan alas : ");
			alas = scan.nextInt();
			scan.nextLine();
			System.out.println("Masukan tinggi : ");
			tinggi = scan.nextInt();
			scan.nextLine();
			System.out.println("Masukan sisi 1 : ");
			sisi1 = scan.nextInt();
			scan.nextLine();
			System.out.println("Masukan sisi 2 : ");
			sisi2 = scan.nextInt();
			scan.nextLine();
			System.out.println("Masukan sisi 3 : ");
			sisi3 = scan.nextInt();
			scan.nextLine();
			Segitiga segitiga = new Segitiga(alas, tinggi, sisi1, sisi2, sisi3);

			segitiga.luas();
			segitiga.keliling();
			break;
		}
	}

	public Testing() {
		int pilih;

		System.out.println("Silahkan Pilih");
		System.out.println("==============");
		System.out.println("1. Bangun Datar");
		System.out.println("2. Bangun Ruang");
		System.out.println("Pilihan : ");
		pilih = scan.nextInt();
		scan.nextLine();

		switch (pilih) {
		case 1:
			Datar();
			break;
		case 2:
			Ruang();
			break;
		}

	}

	public static void main(String[] args) {
		new Testing();
	}
}
