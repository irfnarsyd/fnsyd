public class GanjilGenap implements Runnable {

	int angka;

	public GanjilGenap(int angka) {
		System.out.println("Tunggu 30 detik untuk mengetahui bilangan Genap/Ganjil");
		this.angka = angka;
	}

	@Override
	public void run() {
		try {
			Thread.sleep(30000);
			if (angka % 2 == 1) {
				System.out.println("Ganjil");
			} else {
				System.out.println("Genap");
			}
		} catch (InterruptedException e) {
		}
	}

}