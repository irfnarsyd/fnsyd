public class Fibonacci implements Runnable {
	int angka;

	public Fibonacci(int angka) {
		this.angka = angka;
	}

	@Override
	public void run() {
		int n = 20, angka1 = 0, angka2 = 1;
		System.out.println(n + " Angka Fibonacci: ");

		for (int i = 1; i <= n; ++i) {
			System.out.print(angka1 + " ");
			int sum = angka1 + angka2;
			angka1 = angka2;
			angka2 = sum;

			if (sum != angka1 + angka2 && angka1 != angka2 && angka2 != sum) {
				System.out.println("Bukan bilangan Fibonacci");
			} else {
				System.out.println("Merupakan Bilangan Fibonacci");
			}
		}
		System.out.println("Jika angka yang dimasukan tidak ada, maka angka tersebut bukanlah bilangan Fibonacci");
	}

}
