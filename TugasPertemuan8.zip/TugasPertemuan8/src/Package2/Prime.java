package Package2;

public class Prime implements Runnable {

	@Override
	public void run() {
		System.out.println("Silahkan Tunggu 1 menit untuk hasil 10 bilangan Prima pertama ");
		try {
			Thread.sleep(60000);
			int n = 30;
			System.out.println("10 Bilangan Prima Pertama adalah : ");
			for (int i = 2; i < n; i++) {
				boolean isPrima = true;

				for (int j = 2; j < i; j++) {
					if (i % j == 0) {
						isPrima = false;
						break;

					}
				}
				if (isPrima == true) {
					System.out.print(i + " , ");
				}
			}
			System.out.println(" ");
			System.out.println("Silahkan Tunggu 1 menit untuk hasil 20 bilangan Fibonacci pertama");
		} catch (InterruptedException e) {

		}
	}

}
