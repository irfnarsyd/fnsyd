package Package2;

import Package2.Fibonacci;
import Package2.Prime;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Prime prime = new Prime();
		Thread thread = new Thread(prime);
		thread.start();

		Fibonacci fibonacci = new Fibonacci();
		Thread thread2 = new Thread(fibonacci);
		thread2.start();

	}

}
