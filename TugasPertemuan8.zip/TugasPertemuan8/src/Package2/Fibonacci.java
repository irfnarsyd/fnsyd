package Package2;

public class Fibonacci implements Runnable {

	@Override
	public void run() {
		try {
			Thread.sleep(120000);
			int n = 20, angka1 = 0, angka2 = 1;
			System.out.println(n + " Angka Fibonacci: ");

			for (int i = 1; i <= n; ++i) {
				System.out.print(angka1 + " , ");
				int sum = angka1 + angka2;
				angka1 = angka2;
				angka2 = sum;
			}
		} catch (InterruptedException e) {

		}
	}

}
