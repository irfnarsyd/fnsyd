import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int angka;

		System.out.println("Masukkan inputan angka(integer) : ");
		angka = scan.nextInt();
		scan.nextLine();
		GanjilGenap ganjilGenap = new GanjilGenap(angka);
		Thread thread = new Thread(ganjilGenap);
		thread.start();

		Fibonacci fibonacci = new Fibonacci(angka);
		Thread thread2 = new Thread(fibonacci);
		thread2.start();

	}

}
